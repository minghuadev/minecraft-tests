#ifndef JASON_SPIRIT_READER_TEST
#define JASON_SPIRIT_READER_TEST

/* Copyright (c) 2007 John W Wilkinson

   This source code can be used for any purpose as long as
   this comment is retained. */

#pragma once

namespace json_spirit
{
    void test_reader();
}

#endif
