
C Grammar checker
Copyright (c) 2001-2004 Hartmut Kaiser
http://spirit.sourceforge.net/

Use, modification and distribution is subject to the Boost Software
License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
http://www.boost.org/LICENSE_1_0.txt)

-------------------------------------------------------------------------------

The C grammar parser is a full working example of using the Spirit
library and is able to parse the full ANSI C language. 

The C grammar is adapted from
	http://www.lysator.liu.se/c/ANSI-C-grammar-y.html
	http://www.lysator.liu.se/c/ANSI-C-grammar-l.html 

Not implemented is the analysis of typedef's because it requires semantic
analysis of the parsed code, which is beyond the scope of this sample.

The files in the test_files directory are adapted from
	http://www.bagley.org/~doug/shootout
and where modified slightly to avoid preprocessing (#include's and 
#define's are commented out, where possible).

The test files are parsed correctly.

