/* -*- mode: c -*-
 * $Id: HelloWorld.c,v 1.4 2003/03/05 10:16:18 djowel Exp $
 * http://www.bagley.org/~doug/shootout/
 */

/*
#include <stdio.h>
*/

int main() {
    fputs("hello world\n", stdout);
    return(0);
}
