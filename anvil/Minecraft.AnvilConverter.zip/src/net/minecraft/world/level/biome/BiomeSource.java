package net.minecraft.world.level.biome;


public interface BiomeSource {

    public int getBiomeId(int x, int z);

}
