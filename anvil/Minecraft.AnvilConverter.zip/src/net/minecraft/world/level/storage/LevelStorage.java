package net.minecraft.world.level.storage;

/**
 * Copyright Mojang AB.
 * 
 * Don't do evil.
 */

public interface LevelStorage {
    public static final String NETHER_FOLDER = "DIM-1";
    public static final String ENDER_FOLDER = "DIM1";
}
