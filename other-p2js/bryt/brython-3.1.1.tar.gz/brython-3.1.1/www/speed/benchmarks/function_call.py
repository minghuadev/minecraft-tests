def f(x):
    return x
for i in range(1000000):
    f(i)

