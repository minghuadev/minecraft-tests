a = [0]

for i in range(1000000):
    a[0] = i
