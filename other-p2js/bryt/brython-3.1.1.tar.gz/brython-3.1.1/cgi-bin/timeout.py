#!c:/python33/python.exe
# -*- coding: utf-8 -*-


from time import sleep


print('Content-type: text/plain')
print()

sleep(10)
print('script cgi with GET')
