#!c:/python33/python.exe
# -*- coding: utf-8 -*-


print('Content-type: text/plain\n')
print()

print('script cgi with GET')
