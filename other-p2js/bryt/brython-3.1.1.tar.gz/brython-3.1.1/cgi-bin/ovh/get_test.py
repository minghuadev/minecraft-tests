#!/usr/bin/python
# -*- coding: utf-8 -*-


print('Content-type: text/plain\n\n')

print('script cgi with GET')
