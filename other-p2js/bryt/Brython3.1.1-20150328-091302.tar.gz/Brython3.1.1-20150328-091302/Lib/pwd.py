
def getpwuid():
    pass
