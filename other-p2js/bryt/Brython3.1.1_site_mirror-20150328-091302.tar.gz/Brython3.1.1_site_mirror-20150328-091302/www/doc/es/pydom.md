Módulo **browser.pydom**
----------------------

<h1>pydom API</h1>

pydom emula la funcionalidad de [jQuery](http://www.jquery.com) en lo posible. Se usa la 
[documentación](http://api.jquery.com) de la API de jQuery como guía para usar pydom.

Para ver ejemplos le puedes dar un vistazo a la documentación de [pydom](../en/pydom/index.html).
