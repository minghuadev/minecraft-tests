import sys
try:
    raise TypeError
except TypeError as exc:
    print(type(exc))
    tb = sys.exc_info()[2]
    print(tb)
    TracebackType = type(tb)
    FrameType = type(tb.tb_frame)
    tb = None; del tb
print('ok')