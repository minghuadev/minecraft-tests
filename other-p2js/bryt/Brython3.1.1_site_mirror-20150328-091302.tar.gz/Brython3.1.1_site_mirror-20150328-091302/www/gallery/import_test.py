valude = "fsdfoo"
def func(x):
    return x.upper()