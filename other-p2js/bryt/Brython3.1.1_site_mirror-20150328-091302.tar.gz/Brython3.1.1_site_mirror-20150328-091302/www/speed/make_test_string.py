import os

out = open('bench_str.txt', 'w')

out.write('import time\n\n')

tests=["assignment.py", "augm_assign.py", "assignment_float.py",
       "build_dict.py", "set_dict_item.py", "build_list.py",
       "set_list_item.py", "add_integers.py", "add_strings.py",
       "str_of_int.py",
       "create_function.py", "function_call.py"] #,"generator.py"]

for test in tests:
    out.write('t0 = time.time()\n')
    path = os.path.join(os.getcwd(), 'benchmarks', test)
    out.write(open(path).read().strip())
    out.write('\nprint("%s", time.time()-t0)\n\n' %test)
out.close()

src = open('bench_str.txt').read()
src = src.replace('\n',r'\n')

out = open('bench_str_pypy.txt', 'w')
out.write("'''"+src+"'''")
out.close()