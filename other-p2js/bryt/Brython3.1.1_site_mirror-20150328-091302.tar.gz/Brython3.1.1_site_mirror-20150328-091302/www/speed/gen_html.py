out = open('result_table.html', 'w')
out1 = open('result_table_spaces.txt', 'w')

lines = open('result_table.txt').readlines()

def f(num):
    return num.replace(',','.')

width = 10

out.write('<table border=1>\n')

out.write('<tr>\n')
out.write('<th rowspan="2">Test</th>\n')
out.write('<th colspan="4">Result (ms)</th>\n')
out.write('<th colspan="3">X slower than CPython</th>\n')
out.write('</tr>\n')

out.write('<tr>\n')
for cell in lines[0].rstrip().split('\t')[1:]:
    out.write('<th>%s</th>\n' %cell)
    out1.write(cell.center(width))
out.write('</tr>\n')
out1.write('\n')

for line in lines[1:-1]:    
    print(line.expandtabs())
    out.write('<tr>\n')
    for i,cell in enumerate(line.rstrip().split('\t')):
        if i==0:
            out.write('<td>%s</td>\n' %cell)
            out1.write(cell.ljust(18))
        else:
            out.write('<td align="right">%s</td>\n' %f(cell))
            out1.write(cell.rjust(width))
    out.write('</tr>\n')
    out1.write('\n')

out.write('<tr>\n')
out.write('<th colspan="5" align="right">Mean</th>\n')
for cell in lines[-1].strip().split('\t'):
    out.write('<td align="right"><b>%s</b></td>\n' %f(cell))
out.write('</tr>\n')

out.close()    
out1.close()