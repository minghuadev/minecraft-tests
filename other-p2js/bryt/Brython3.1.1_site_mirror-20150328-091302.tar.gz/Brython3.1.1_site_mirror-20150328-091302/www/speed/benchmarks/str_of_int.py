for _i in range(100000):
    str(_i)
