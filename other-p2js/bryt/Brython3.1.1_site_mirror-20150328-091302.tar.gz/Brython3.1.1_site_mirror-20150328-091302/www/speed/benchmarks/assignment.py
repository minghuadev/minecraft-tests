for i in range(1000000):
    a = 1
