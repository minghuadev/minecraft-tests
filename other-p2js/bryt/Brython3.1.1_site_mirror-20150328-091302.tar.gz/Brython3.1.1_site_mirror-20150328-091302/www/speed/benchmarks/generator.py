def f():
    while True:
        yield 1
g = f()
for i in range(100000):
    next(g)
