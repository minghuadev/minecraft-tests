#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import cgi
import time
import json
import sys



try:
    path = os.path.join(os.getcwd(),__file__)
    scripts_path = os.path.join(os.path.dirname(os.path.dirname(path)),
        'www','speed','benchmarks')
    
    fs = cgi.FieldStorage()
    filename = fs['filename'].value
    
    t0 = time.time()
    src = open(os.path.join(scripts_path,filename)).read()
    exec(src)
    t1 = time.time()
    print('Content-type: text/html\n\n')
    print(json.dumps({'filename': filename, 'timing': int((t1-t0) * 1000.0),
        'version': sys.version}))
except:
    import cStringIO
    out = cStringIO.StringIO()
    import traceback
    traceback.print_exc(file=out)
    print('Content-type: text/plain\n\n')
    print(sys.version)
    print(out.getvalue())
    print(__file__)
    print(os.getcwd())