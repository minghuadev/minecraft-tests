#!/usr/bin/env python 
import py

def main(args):
    py.test.cmdline.main(args) 
