
def test_one(): 
    assert 42 == 43

class TestClass(object): 
    def test_method_one(self): 
        assert 42 == 43 
