
class TestClass:
    disabled = True
    def test_func():
        pass
