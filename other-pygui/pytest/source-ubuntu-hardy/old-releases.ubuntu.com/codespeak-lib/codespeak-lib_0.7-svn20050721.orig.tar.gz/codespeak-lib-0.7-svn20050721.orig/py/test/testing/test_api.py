
import py

def test_skipfailure():
    def f():
        raise ValueError()
    excinfo = py.test.raises(
                py.test.Item.Skipped, 
                "py.test.skip_on_error(f)")
    print excinfo
    assert str(excinfo).find("ValueError") != -1 

def test_skip_on_error_with_no_failure():
    def f():
        return 42 
    assert py.test.skip_on_error(f) == 42 
