"""


""" 
from py.xml import Namespace, Tag
from py.__.xmlobj.visit import SimpleUnicodeVisitor 

class HtmlVisitor(SimpleUnicodeVisitor): 
    def repr_attribute(self, attrs, name): 
        if name == 'class_':
            value = getattr(attrs, name) 
            if value is None: 
                return
        return super(HtmlVisitor, self).repr_attribute(attrs, name) 

class HtmlTag(Tag): 
    def unicode(self, indent=2):
        l = []
        HtmlVisitor(l.append, indent, shortempty=False).visit(self) 
        return u"".join(l) 

# exported plain html namespace 
class html(Namespace):
    __tagclass__ = HtmlTag
    __stickyname__ = True 
    __tagspec__ = dict([(x,1) for x in ( 
        "h1,h2,h3,h5,h6,p,b,i,a,div,span,code,"
        "html,head,title,style,table,tr,tt,"
        "td,th,link,img,meta,body,pre,br,ul,"
        "ol,li,em,form,input,select,option,"
        "button,script,colgroup,col,map,area,"
        "blockquote,dl,dt,dd,strong"
    ).split(',') if x])

    class Style(object): 
        def __init__(self, **kw): 
            for x, y in kw.items():
                x = x.replace('_', '-')
                setattr(self, x, y) 

