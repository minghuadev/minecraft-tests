import py

#
# main entry point
#

def main():
    config, args = py.test.Config.parse(py.std.sys.argv[1:])
    sessionclass = config.getsessionclass() 
    session = sessionclass(config)
    try: 
        failures = session.main(args)
        if failures: 
            raise SystemExit, 1 
    except KeyboardInterrupt: 
        if not config.option.verbose: 
            print
            print "KeyboardInterrupt"
            raise SystemExit, 2
        else: 
            raise 
