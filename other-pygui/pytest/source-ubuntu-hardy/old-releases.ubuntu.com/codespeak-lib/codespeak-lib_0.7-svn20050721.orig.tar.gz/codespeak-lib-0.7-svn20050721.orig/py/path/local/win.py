"""
module for win-specific local path stuff

(implementor needed :-)
"""

class WinMixin:
    pass
