
samplefile = 'samplefile\n'
samplepickle = {}

class sampledir:
    otherfile = 'otherfile'

class otherdir:
    init = 42

class execfile:
    x = 42
