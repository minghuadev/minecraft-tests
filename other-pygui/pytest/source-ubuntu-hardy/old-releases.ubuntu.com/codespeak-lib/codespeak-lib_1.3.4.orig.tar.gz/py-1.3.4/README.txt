The py lib is a Python development support library featuring
the following tools and modules:

* py.test: tool for distributed automated testing
* py.code: dynamic code generation and introspection
* py.path:  uniform local and svn path objects

For questions and more information please visit http://pylib.org
