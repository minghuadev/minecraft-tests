
pytest_plugins = "skipping", "pytester", "tmpdir"

