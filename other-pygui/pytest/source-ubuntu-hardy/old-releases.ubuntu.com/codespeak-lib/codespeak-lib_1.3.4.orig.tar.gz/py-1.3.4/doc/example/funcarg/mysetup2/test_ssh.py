
class TestClass:
    def test_function(self, mysetup):
        conn = mysetup.getsshconnection()
        # work with conn
