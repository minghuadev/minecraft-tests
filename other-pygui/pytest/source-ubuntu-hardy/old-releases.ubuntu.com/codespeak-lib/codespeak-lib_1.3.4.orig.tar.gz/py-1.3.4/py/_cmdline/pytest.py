#!/usr/bin/env python
import py

def main(args=None):
    raise SystemExit(py.test.cmdline.main(args))
