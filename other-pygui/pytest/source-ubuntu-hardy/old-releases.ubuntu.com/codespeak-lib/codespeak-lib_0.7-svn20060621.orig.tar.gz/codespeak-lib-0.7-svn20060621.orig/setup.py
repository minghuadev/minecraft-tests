import py 
py._dist.setup(py) 
