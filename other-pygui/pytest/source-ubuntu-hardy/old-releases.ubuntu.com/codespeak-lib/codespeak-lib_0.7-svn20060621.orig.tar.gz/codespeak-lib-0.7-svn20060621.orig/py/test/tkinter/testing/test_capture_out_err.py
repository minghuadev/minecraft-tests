import py
from py.__.test.tkinter import backend
ReportBackend = backend.ReportBackend

datadir = py.magic.autopath().dirpath('data')

def test_capture_out_err():
    config, args = py.test.Config.parse([])
    backend = ReportBackend()
    backend.start_tests(config = config,
                                 args = [str(datadir / 'filetest.py')],
                                 tests = [])
    while backend.running:
        backend.update()
    backend.update()
    store = backend.get_store()
    assert len(store.get(failed = True)) == 1
    failed = store.get(failed = True)[0]
    assert failed.stdout == 'STDOUT'
    assert failed.stderr == 'STDERR'
