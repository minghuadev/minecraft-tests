import py

class BrokenRepr1:
    """A broken class with lots of broken methods. Let's try to make the test framework 
    immune to these."""
    foo=0
    def __repr__(self):
        raise Exception("Ha Ha fooled you, I'm a broken repr().")

class BrokenRepr2:
    """A broken class with lots of broken methods. Let's try to make the test framework 
    immune to these."""
    foo=0
    def __repr__(self):
        raise "Ha Ha fooled you, I'm a broken repr()."

    
class TestBrokenClass:

    def test_explicit_bad_repr(self):
        t = BrokenRepr1()
        py.test.raises(Exception, 'repr(t)')
        
    def test_implicit_bad_repr1(self):
        t = BrokenRepr1()
        assert t.foo == 1

    def test_implicit_bad_repr2(self):
        t = BrokenRepr2()
        assert t.foo == 1

