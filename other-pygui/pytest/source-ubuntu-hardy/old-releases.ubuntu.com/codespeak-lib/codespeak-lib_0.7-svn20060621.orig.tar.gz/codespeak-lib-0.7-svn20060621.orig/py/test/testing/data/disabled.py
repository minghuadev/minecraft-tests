class TestDisabled:
    disabled = True
    def test_method(self): 
        pass
