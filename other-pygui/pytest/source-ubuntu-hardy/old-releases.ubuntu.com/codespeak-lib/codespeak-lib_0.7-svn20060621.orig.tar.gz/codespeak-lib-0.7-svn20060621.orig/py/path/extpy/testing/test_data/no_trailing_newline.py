test = True
if __name__ == '__main__':
    pass

#############################################################################
# 2004 M.E.Farmer Jr.
# Python license