
disabled = True

def setup_module(mod):
    raise ValueError

class TestClassOne:
    def test_func(self):
        raise ValueError

class TestClassTwo:
    def setup_class(cls):
        raise ValueError
    def test_func(self):
        raise ValueError

