import py

def is_on_path(name):
    try:
        py.path.local.sysfind(name)
    except py.error.ENOENT:
        return False
    else:
        return True


