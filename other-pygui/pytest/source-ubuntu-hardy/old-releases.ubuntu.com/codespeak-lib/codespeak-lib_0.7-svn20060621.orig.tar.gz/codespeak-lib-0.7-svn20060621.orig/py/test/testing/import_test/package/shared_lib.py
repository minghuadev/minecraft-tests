"""
Just a dummy module
"""
