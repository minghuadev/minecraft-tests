""" compatibility modules (taken from 2.4.4) """

