""" ad-hoc networking mechanism """
