""" assertion and py.test helper API."""
