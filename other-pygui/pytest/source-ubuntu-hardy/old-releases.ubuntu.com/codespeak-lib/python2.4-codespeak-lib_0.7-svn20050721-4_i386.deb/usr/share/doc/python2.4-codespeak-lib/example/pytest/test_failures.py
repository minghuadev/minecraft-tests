
import py
failure_demo = py.magic.autopath().dirpath('failure_demo.py')

def test_failure_demo_fails_properly(): 
    config, args = py.test.Config.parse([]) 
    session = config.getsessionclass()(config, py.std.sys.stdout)
    session.main([failure_demo]) 
    l = session.getitemoutcomepairs(py.test.Item.Failed)
    assert len(l) == 21 
    l = session.getitemoutcomepairs(py.test.Item.Passed)
    assert not l 
