try:
    BaseException = BaseException
except NameError:
    BaseException = Exception
