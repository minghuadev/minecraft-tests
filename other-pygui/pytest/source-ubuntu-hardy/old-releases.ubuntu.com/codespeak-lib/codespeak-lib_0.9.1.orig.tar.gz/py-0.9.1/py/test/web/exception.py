class CSSError(Exception):
    """raised when there's a problem with the CSS"""

class HTMLError(Exception):
    """raised when there's a problem with the HTML"""

