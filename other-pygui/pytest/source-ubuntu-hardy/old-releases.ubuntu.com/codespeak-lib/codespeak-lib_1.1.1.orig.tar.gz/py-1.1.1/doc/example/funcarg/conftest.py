import py

collect_ignore = 'mysetup', 'mysetup2', 'test_simpleprovider.py', 'parametrize'
