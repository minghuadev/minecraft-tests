
class MyApp:
    def question(self):
        return 6 * 9 

