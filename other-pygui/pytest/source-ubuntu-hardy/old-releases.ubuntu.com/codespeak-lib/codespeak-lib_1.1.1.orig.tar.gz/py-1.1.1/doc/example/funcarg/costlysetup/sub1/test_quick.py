
def test_quick():
    pass
