HOW TO INSTALL AND RUN THE PROGRAMS IN THIS ZIP FILE
====================================================

This zip file contains the "Thinking in Tkinter" Python files, plus a driver 
program called thinking.py and a batch file (thinking.bat).


INSTALLATION 
==========================================
To install these files, simply unzip the zip file into a directory (i.e. folder) 
of your choice.


EXECUTION
==========================================
You can then start the programs from the command prompt by entering:

      python thinking.py

If you are in a Windows environment, you can start thinking.bat from the command 
prompt simply by entering:

     thinking
     
 
